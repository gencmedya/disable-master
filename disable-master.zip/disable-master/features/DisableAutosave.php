<?php
namespace DisableMaster\Features;

class DisableAutosave {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_autosave']) && $options['disable_autosave']) {
            add_action('wp_print_scripts', [$this, 'deregister_autosave']);
        }
    }

    public function deregister_autosave() {
        wp_deregister_script('autosave');
    }
}
?>