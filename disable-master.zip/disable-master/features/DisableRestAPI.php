<?php
namespace DisableMaster\Features;

class DisableRestApi {
    public function __construct() {
        add_action('init', [$this, 'disable_rest_api']);
    }

    public function disable_rest_api() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_rest_api']) && $options['disable_rest_api']) {
            add_filter('rest_authentication_errors', [$this, 'rest_authentication_errors']);
        }
    }

    public function rest_authentication_errors($result) {
        if (!empty($result)) {
            return $result;
        }
        if (!is_user_logged_in()) {
            return new \WP_Error('rest_disabled', __('REST API is disabled.', 'disable-master'), array('status' => 401));
        }
        return $result;
    }
}
?>