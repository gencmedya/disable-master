<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableSelfPings {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        add_action('pre_ping', [$this, 'disable_self_pings']);
    }

    public function disable_self_pings(&$links) {
        $options = get_option('disable_master_options');
        if (isset($options['disable_self_pings']) && $options['disable_self_pings']) {
            foreach ($links as $l => $link) {
                if (0 === strpos($link, home_url())) {
                    unset($links[$l]);
                }
            }
        }
    }
}
?>