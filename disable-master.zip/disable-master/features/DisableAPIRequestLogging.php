<?php
namespace DisableMaster\Features;

class DisableAPIRequestLogging {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            add_filter('rest_pre_serve_request', '__return_false', 99);
        }
    }
}
?>