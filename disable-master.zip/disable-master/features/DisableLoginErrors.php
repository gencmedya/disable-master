<?php
namespace DisableMaster\Features;

class DisableLoginErrors {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_login_errors']) && $options['disable_login_errors']) {
            add_filter('login_errors', [$this, 'remove_login_errors']);
        }
    }

    public function remove_login_errors() {
        return null;
    }
}
?>