<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableSearch {
    public function __construct() {
        add_action('init', [$this, 'disable_search']);
    }

    public function disable_search() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_search']) && $options['disable_search']) {
            // Arama sorgularını devre dışı bırak
            add_action('parse_query', [$this, 'disable_search_query'], 10, 1);

            // Arama formlarını ve butonlarını gizle
            add_action('wp_footer', [$this, 'hide_search_form']);

            // Admin panelinde arama kutusunu devre dışı bırak
            add_action('admin_head', [$this, 'disable_admin_search']);
        }
    }

    public function disable_search_query($query, $error = true) {
        if (is_search() && !is_admin()) {
            $query->is_search = false;
            $query->query_vars['s'] = false;
            $query->query['s'] = false;
            if ($error == true) {
                $query->is_404 = true;
            }
        }
    }

    public function hide_search_form() {
        echo '
        <style>
            form.search-form,
            input[type="search"],
            .search-submit {
                display: none !important;
            }
        </style>
        ';
    }

    public function disable_admin_search() {
        echo '
        <style>
            #adminbarsearch,
            .search-box {
                display: none !important;
            }
        </style>
        ';
    }
}
?>