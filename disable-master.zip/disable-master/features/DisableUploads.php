<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableUploads {
    private $is_active;

    public function __construct($is_active = false) {
        $this->is_active = $is_active;
        if ($this->is_active) {
            add_action('admin_init', [$this, 'disable_uploads']);
            add_filter('user_has_cap', [$this, 'disable_upload_capabilities'], 10, 3);
        }
    }

    public function disable_uploads() {
        if (is_admin()) {
            // Medya yüklemelerini devre dışı bırak
            add_filter('wp_handle_upload_prefilter', function ($file) {
                return ['error' => esc_html__('Uploads are disabled.', 'disable-master')];
            });

            // Eklenti ve tema yüklemelerini devre dışı bırak
            add_action('admin_menu', function() {
                remove_submenu_page('plugins.php', 'plugin-install.php');
                remove_submenu_page('themes.php', 'theme-install.php');
            }, 999);

            // Eklenti ve tema yükleme sayfalarına erişimi engelle
            add_action('admin_init', function() {
                global $pagenow;
                if ($pagenow === 'plugin-install.php' || $pagenow === 'theme-install.php') {
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('You do not have permission to upload plugins or themes.', 'disable-master') . '</p></div>';
                    });
                    wp_redirect(admin_url());
                    exit;
                }
            });

            // Yükleme butonlarını gizle
            add_action('admin_enqueue_scripts', function() {
                echo '<style>
                    .upload-plugin, .upload-theme, .upload-new-media, .page-title-action,
                    #menu-appearance ul li a[href*="theme-install.php"],
                    #menu-plugins ul li a[href*="plugin-install.php"],
                    .wp-media-buttons .button {
                        display: none !important;
                    }
                    .error {
                        display: block;
                        color: red;
                        margin-top: 10px;
                    }
                </style>';
            });

            // Yükleme hatası göstermek için upload-new.php sayfasını güncelle
            add_action('admin_footer-upload.php', function() {
                echo '<script>
                    document.addEventListener("DOMContentLoaded", function() {
                        const uploader = document.getElementById("plupload-upload-ui");
                        if (uploader) {
                            uploader.style.display = "none";
                            const message = document.createElement("div");
                            message.className = "error";
                            message.innerHTML = "' . esc_html__('Uploads are disabled.', 'disable-master') . '";
                            uploader.parentNode.insertBefore(message, uploader);
                        }
                    });
                </script>';
            });
        }
    }

    public function disable_upload_capabilities($allcaps, $cap, $args) {
        if (!empty($cap[0]) && $cap[0] === 'upload_files') {
            $allcaps[$cap[0]] = false;
        }
        return $allcaps;
    }
}
?>
