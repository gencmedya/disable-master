<?php
namespace DisableMaster\Features;

class DisableRevisions {
    public function __construct() {
        add_action('init', [$this, 'disable_revisions']);
    }

    public function disable_revisions() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_revisions']) && $options['disable_revisions']) {
            if (!defined('WP_POST_REVISIONS')) {
                define('WP_POST_REVISIONS', false);
            }
        }
    }
}
?>