<?php
namespace DisableMaster\Features;

class DisableAdminAjaxOnFrontend {
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'disable_admin_ajax_on_frontend'], 99);
    }

    public function disable_admin_ajax_on_frontend() {
        $options = get_option('disable_master_options');
        if (!is_admin() && isset($options['disable_admin_ajax']) && $options['disable_admin_ajax']) {
            wp_deregister_script('wp-embed');
            wp_deregister_script('heartbeat');
            wp_deregister_script('admin-ajax');
        }
    }
}
?>