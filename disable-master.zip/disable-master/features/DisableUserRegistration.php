<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableUserRegistration {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_user_registration']) && $options['disable_user_registration']) {
            add_action('admin_init', [$this, 'remove_user_registration_settings']);
            add_action('admin_head-options-general.php', [$this, 'hide_user_registration_settings_css']);
        }
    }

    public function remove_user_registration_settings() {
        add_filter('option_default_role', function() {
            return 'subscriber';
        });
        add_filter('pre_option_users_can_register', '__return_zero');
        remove_action('admin_init', 'default_role_init');
        remove_filter('pre_option_default_role', 'default_role_filter');
    }

    public function hide_user_registration_settings_css() {
        echo '<style>
            #users_can_register,
            select[name="default_role"] {
                pointer-events: none;
                opacity: 0.5;
            }
        </style>';
    }
}
?>