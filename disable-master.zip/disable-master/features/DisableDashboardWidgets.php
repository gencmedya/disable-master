<?php
namespace DisableMaster\Features;

class DisableDashboardWidgets {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_dashboard']) && $options['disable_dashboard']) {
            add_action('admin_init', [$this, 'redirect_dashboard']);
            add_action('admin_menu', [$this, 'remove_dashboard_menu'], 999);
            remove_action('welcome_panel', 'wp_welcome_panel');
        }
    }

    public function redirect_dashboard() {
        global $pagenow;
        if ($pagenow === 'index.php') {
            wp_redirect(admin_url('edit.php'));
            exit;
        }
    }

    public function remove_dashboard_menu() {
        remove_menu_page('index.php');
    }
}
?>