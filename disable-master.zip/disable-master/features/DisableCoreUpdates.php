<?php
namespace DisableMaster\Features;

class DisableCoreUpdates {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_core_updates']) && $options['disable_core_updates']) {
            add_filter('automatic_updater_disabled', '__return_true');
            add_filter('auto_update_core', '__return_false');

            if (!defined('WP_AUTO_UPDATE_CORE')) {
                define('WP_AUTO_UPDATE_CORE', false);
            }

            // Disable access to update-core.php page
            add_action('admin_menu', [$this, 'disable_core_updates_admin_menu'], 999);

            // Redirect users who try to access update-core.php directly
            add_action('admin_init', [$this, 'disable_core_updates_redirect']);

            // Hide update notifications in the admin bar
            add_action('wp_before_admin_bar_render', [$this, 'disable_core_updates_admin_bar']);

            // Hide update notifications
            add_action('admin_menu', [$this, 'disable_core_updates_notifications']);
        }
    }

    public function disable_core_updates_admin_menu() {
        remove_submenu_page('index.php', 'update-core.php');
        remove_menu_page('update-core.php');
    }

    public function disable_core_updates_redirect() {
        global $pagenow;
        if ($pagenow === 'update-core.php') {
            wp_redirect(admin_url());
            exit;
        }
    }

    public function disable_core_updates_admin_bar() {
        global $wp_admin_bar;
        $wp_admin_bar->remove_menu('updates');
    }

    public function disable_core_updates_notifications() {
        remove_action('admin_notices', 'update_nag', 3);
    }
}
?>