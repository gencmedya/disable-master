<?php
namespace DisableMaster\Features;

class DisableApplicationPasswords {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (is_array($options) && isset($options['disable_application_passwords']) && $options['disable_application_passwords']) {
            add_filter('wp_is_application_passwords_available', '__return_false');
        }
    }
}
?>