<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableWidgets {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_widgets']) && $options['disable_widgets']) {
            add_action('widgets_init', [$this, 'unregister_default_wp_widgets'], 11);
            add_action('admin_menu', [$this, 'remove_widgets_menu'], 999);
            add_action('admin_init', [$this, 'disable_widgets_redirect']);
            add_action('wp_head', [$this, 'hide_sidebars_with_css']);
        }
    }

    public function unregister_default_wp_widgets() {
        global $wp_widget_factory;
        $widgets = $wp_widget_factory->widgets;
        foreach ($widgets as $widget) {
            unregister_widget($widget->id_base);
        }
    }

    public function remove_widgets_menu() {
        remove_submenu_page('themes.php', 'widgets.php');
    }

    public function disable_widgets_redirect() {
        global $pagenow;
        if ($pagenow === 'widgets.php') {
            wp_redirect(admin_url());
            exit;
        }
    }

    public function hide_sidebars_with_css() {
        echo '<style type="text/css">
            .widget-area, .sidebar, .sidebar-widget, #secondary {
                display: none !important;
            }
        </style>';
    }
}
?>