<?php
namespace DisableMaster\Features;

class DisablePostLocking {
    public function __construct() {
        add_action('init', [$this, 'disable_post_locking']);
    }

    public function disable_post_locking() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_post_locking']) && $options['disable_post_locking']) {
            remove_action('admin_enqueue_scripts', 'wp_check_post_lock');
            remove_action('wp_ajax_wp_remove_post_lock', 'wp_ajax_wp_remove_post_lock');
        }
    }
}
?>