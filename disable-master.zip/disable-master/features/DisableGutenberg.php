<?php
namespace DisableMaster\Features;

class DisableGutenberg {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_gutenberg']) && $options['disable_gutenberg']) {
            add_filter('use_block_editor_for_post_type', '__return_false', 10);
        }
    }
}
?>