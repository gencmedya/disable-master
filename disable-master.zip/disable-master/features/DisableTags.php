<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableTags {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_tags']) && $options['disable_tags']) {
            add_action('init', [$this, 'remove_tags_support']);
            add_action('admin_menu', [$this, 'remove_tags_admin_menu']);
            add_action('admin_menu', [$this, 'remove_tags_meta_box']);
            add_filter('manage_post_posts_columns', [$this, 'remove_tags_columns']);
            add_action('template_redirect', [$this, 'disable_tag_archives']);
            add_action('wp_head', [$this, 'hide_tags_with_css']);
            add_filter('get_the_terms', [$this, 'remove_tag_links_from_meta'], 10, 2);
            add_filter('the_content', [$this, 'remove_tags_from_content'], 20);
            add_filter('the_excerpt', [$this, 'remove_tags_from_content'], 20);
            add_filter('widget_tag_cloud_args', [$this, 'remove_tag_cloud_widget']);
            add_action('init', [$this, 'remove_tags_from_wp_head']);
            add_filter('post_class', [$this, 'remove_tags_from_post_class']);
            add_filter('the_content', [$this, 'remove_tags_links_from_content_manually'], 20);
            add_filter('the_excerpt', [$this, 'remove_tags_links_from_content_manually'], 20);
            add_action('wp', [$this, 'remove_theme_tag_hooks']);
        }
    }

    public function remove_tags_support() {
        unregister_taxonomy_for_object_type('post_tag', 'post');
    }

    public function remove_tags_admin_menu() {
        remove_submenu_page('edit.php', 'edit-tags.php?taxonomy=post_tag');
    }

    public function remove_tags_meta_box() {
        remove_meta_box('tagsdiv-post_tag', 'post', 'side');
    }

    public function remove_tags_columns($columns) {
        unset($columns['tags']);
        return $columns;
    }

    public function disable_tag_archives() {
        if (is_tag()) {
            wp_redirect(home_url());
            exit();
        }
    }

    public function hide_tags_with_css() {
        echo '<style>
            .entry-tags,
            a[rel="tag"],
            .tagcloud {
                display: none !important;
            }
        </style>';
    }

    public function remove_tag_links_from_meta($terms, $taxonomy) {
        if ($taxonomy === 'post_tag') {
            return [];
        }
        return $terms;
    }

    public function remove_tags_from_content($content) {
        $content = preg_replace('/<p class="entry-tags ".*?<\/p>/', '', $content);
        return $content;
    }

    public function remove_tag_cloud_widget($args) {
        return [];
    }

    public function remove_tags_from_wp_head() {
        remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
    }

    public function remove_tags_from_post_class($classes) {
        foreach ($classes as $key => $class) {
            if (strpos($class, 'tag-') === 0) {
                unset($classes[$key]);
            }
        }
        return $classes;
    }

    public function remove_tags_links_from_content_manually($content) {
        $content = preg_replace('/<a[^>]*rel="tag"[^>]*>[^<]*<\/a>/', '', $content);
        return $content;
    }

    public function remove_theme_tag_hooks() {
        // Common hooks that themes might use
        remove_action('wp_head', 'theme_tag_function');
        remove_action('wp_footer', 'theme_tag_function');
    }
}
?>