<?php
namespace DisableMaster\Features;

class DisableFeed {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_feed']) && $options['disable_feed']) {
            add_action('do_feed', [$this, 'redirect_feed'], 1);
            add_action('do_feed_rdf', [$this, 'redirect_feed'], 1);
            add_action('do_feed_rss', [$this, 'redirect_feed'], 1);
            add_action('do_feed_rss2', [$this, 'redirect_feed'], 1);
            add_action('do_feed_atom', [$this, 'redirect_feed'], 1);
        }
    }

    public function redirect_feed() {
        wp_redirect(home_url());
        exit;
    }
}
?>