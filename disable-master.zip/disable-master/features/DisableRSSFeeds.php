<?php
namespace DisableMaster\Features;

class DisableRssFeeds {
    public function __construct() {
        add_action('init', [$this, 'disable_rss_feeds']);
    }

    public function disable_rss_feeds() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_rss_feeds']) && $options['disable_rss_feeds']) {
            add_action('do_feed', [$this, 'redirect_to_home'], 1);
            add_action('do_feed_rdf', [$this, 'redirect_to_home'], 1);
            add_action('do_feed_rss', [$this, 'redirect_to_home'], 1);
            add_action('do_feed_rss2', [$this, 'redirect_to_home'], 1);
            add_action('do_feed_atom', [$this, 'redirect_to_home'], 1);
        }
    }

    public function redirect_to_home() {
        wp_redirect(home_url());
        exit;
    }
}
?>