<?php
namespace DisableMaster\Features;

class DisableAdminBar {
    public function __construct() {
        add_action('init', [$this, 'disable_admin_bar']);
    }

    public function disable_admin_bar() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_admin_bar']) && $options['disable_admin_bar']) {
            add_filter('show_admin_bar', '__return_false');
        }
    }
}
?>