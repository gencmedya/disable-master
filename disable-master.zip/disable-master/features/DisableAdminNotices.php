<?php
namespace DisableMaster\Features;

class DisableAdminNotices {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_admin_notices']) && $options['disable_admin_notices']) {
            $this->disable_admin_notices();
            add_action('admin_head', [$this, 'hide_notices_with_css']);
        }
    }

    private function disable_admin_notices() {
        add_action('admin_init', function() {
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
            remove_all_actions('network_admin_notices');
        });
    }

    public function hide_notices_with_css() {
        echo '<style>
            .notice, .update-nag, .updated, .error, .is-dismissible {
                display: none !important;
            }
        </style>';
    }
}
?>