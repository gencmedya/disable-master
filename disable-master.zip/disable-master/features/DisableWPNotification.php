<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableWPNotification {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (is_array($options) && isset($options['disable_wp_notification']) && $options['disable_wp_notification']) {
            // Disable WP notifications
            add_filter('automatic_updater_disabled', '__return_true');
            add_filter('auto_core_update_send_email', '__return_false');
            add_filter('send_core_update_notification_email', '__return_false');

            // Disable plugin and theme update emails
            add_filter('auto_plugin_update_send_email', '__return_false');
            add_filter('auto_theme_update_send_email', '__return_false');
        }
    }
}
?>