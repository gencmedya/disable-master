<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableSitemaps {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_sitemaps']) && $options['disable_sitemaps']) {
            // Disable sitemaps
            add_filter('wp_sitemaps_enabled', '__return_false');

            // Remove the sitemap index from the robots.txt file
            add_filter('robots_txt', [$this, 'remove_sitemap_from_robots'], 10, 2);

            // Remove existing sitemap files
            add_action('init', [$this, 'remove_sitemap_files'], 20);
        }
    }

    public function remove_sitemap_from_robots($output, $public) {
        if ($public) {
            $output = preg_replace('/Sitemap: (.*)\s*/i', '', $output);
        }
        return $output;
    }

    public function remove_sitemap_files() {
        $upload_dir = wp_upload_dir();
        $sitemap_files = glob($upload_dir['basedir'] . '/sitemaps/*');
        foreach ($sitemap_files as $sitemap_file) {
            if (is_file($sitemap_file)) {
                wp_delete_file($sitemap_file); // Use wp_delete_file() instead of unlink()
            }
        }
    }
}
?>