<?php
namespace DisableMaster\Features;

class DisablePluginUpdates {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_plugin_updates']) && $options['disable_plugin_updates']) {
            // Hide plugin update notifications
            add_action('admin_menu', function() {
                remove_action('admin_notices', 'update_nag', 3);
                remove_action('network_admin_notices', 'update_nag', 3);
            });

            // Remove update count from admin menu
            add_action('admin_menu', [$this, 'remove_update_count'], 999);

            // Hide update notifications in the admin bar
            add_action('wp_before_admin_bar_render', [$this, 'remove_update_notifications']);

            // Disable access to plugin update pages
            add_action('admin_menu', [$this, 'disable_update_pages'], 999);

            // Redirect users who try to access plugin update pages directly
            add_action('admin_init', [$this, 'redirect_update_pages']);
        }
    }

    public function remove_update_count() {
        global $menu;
        foreach ($menu as $index => $menu_item) {
            if ($menu_item[2] === 'update-core.php') {
                $menu[$index][0] = preg_replace('/<span.*?<\/span>/', '', $menu_item[0]);
            }
        }
    }

    public function remove_update_notifications() {
        global $wp_admin_bar;
        $wp_admin_bar->remove_menu('updates');
    }

    public function disable_update_pages() {
        remove_submenu_page('plugins.php', 'plugin-install.php');
        remove_submenu_page('plugins.php', 'plugin-editor.php');
        remove_menu_page('update-core.php');
    }

    public function redirect_update_pages() {
        global $pagenow;
        if ($pagenow === 'update-core.php' || $pagenow === 'update.php') {
            wp_redirect(admin_url());
            exit;
        }
    }
}
?>