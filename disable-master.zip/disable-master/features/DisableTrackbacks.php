<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableTrackbacks {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_trackbacks']) && $options['disable_trackbacks']) {
            add_filter('xmlrpc_methods', [$this, 'remove_pingback_method']);
        }
    }

    public function remove_pingback_method($methods) {
        unset($methods['pingback.ping']);
        return $methods;
    }
}
?>