<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableWPGenerator {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_wp_generator']) && $options['disable_wp_generator']) {
            remove_action('wp_head', 'wp_generator');
        }
    }
}
?>