<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableSource {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (is_array($options) && isset($options['disable_source']) && $options['disable_source']) {
            add_action('wp_footer', [$this, 'disable_source_code_view']);
        }
    }

    public function disable_source_code_view() {
        echo '<script type="text/javascript">
            document.addEventListener("keydown", function(e) {
                if (e.ctrlKey && (e.key === "u" || e.key === "U")) {
                    e.preventDefault();
                }
            });
        </script>';
    }
}
?>