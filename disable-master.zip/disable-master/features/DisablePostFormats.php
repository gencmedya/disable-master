<?php
namespace DisableMaster\Features;

class DisablePostFormats {
    public function __construct() {
        add_action('after_setup_theme', [$this, 'disable_post_formats'], 11);
    }

    public function disable_post_formats() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_post_formats']) && $options['disable_post_formats']) {
            remove_theme_support('post-formats');
        }
    }
}
?>