<?php
namespace DisableMaster\Features;

class DisableQueryStrings {
    public function __construct() {
        add_action('init', [$this, 'disable_query_strings']);
    }

    public function disable_query_strings() {
        $options = get_option('disable_master_options');
        if (!is_admin() && isset($options['disable_query_strings']) && $options['disable_query_strings']) {
            add_filter('script_loader_src', [$this, 'remove_query_string'], 15);
            add_filter('style_loader_src', [$this, 'remove_query_string'], 15);
        }
    }

    public function remove_query_string($src) {
        $parts = explode('?', $src);
        return $parts[0];
    }
}
?>