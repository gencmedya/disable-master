<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableWooCommerce {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_woocommerce']) && $options['disable_woocommerce']) {
            add_action('admin_menu', [$this, 'disable_woocommerce_admin_menus'], 99);
            add_action('wp_dashboard_setup', [$this, 'disable_woocommerce_dashboard_widgets'], 99);
            add_action('admin_init', [$this, 'disable_woocommerce_admin_notices'], 99);
            add_action('init', [$this, 'disable_woocommerce_post_types_and_taxonomies'], 99);
            add_filter('woocommerce_rest_check_permissions', '__return_false', 99);
            add_action('wp', [$this, 'disable_woocommerce_frontend_features'], 99);
            add_action('wp_enqueue_scripts', [$this, 'disable_woocommerce_scripts_and_styles'], 99);
            add_action('enqueue_block_assets', [$this, 'disable_woocommerce_blocks'], 99);
        }
    }

    public function disable_woocommerce_admin_menus() {
        remove_menu_page('woocommerce');
        remove_submenu_page('woocommerce', 'wc-admin&path=/');
        remove_submenu_page('woocommerce', 'wc-admin&path=/analytics/overview');
        remove_submenu_page('woocommerce', 'wc-admin&path=/customers');
    }

    public function disable_woocommerce_dashboard_widgets() {
        global $wp_meta_boxes;
        unset($wp_meta_boxes['dashboard']['normal']['core']['woocommerce_dashboard_status']);
        unset($wp_meta_boxes['dashboard']['normal']['core']['woocommerce_dashboard_recent_reviews']);
    }

    public function disable_woocommerce_admin_notices() {
        remove_action('admin_notices', 'woothemes_updater_notice');
        remove_action('admin_notices', 'woothemes_updater_plugin_notice');
        remove_action('admin_notices', 'wc_admin_notices');
        remove_action('admin_notices', 'woothemes_helper_notice');
    }

    public function disable_woocommerce_post_types_and_taxonomies() {
        global $wp_post_types, $wp_taxonomies;
        if (isset($wp_post_types['product'])) {
            unregister_post_type('product');
        }
        if (isset($wp_post_types['shop_order'])) {
            unregister_post_type('shop_order');
        }
        if (isset($wp_taxonomies['product_cat'])) {
            unregister_taxonomy('product_cat');
        }
        if (isset($wp_taxonomies['product_tag'])) {
            unregister_taxonomy('product_tag');
        }
    }

    public function disable_woocommerce_frontend_features() {
        if (function_exists('is_woocommerce') && is_woocommerce()) {
            wp_redirect(home_url());
            exit;
        }
    }

    public function disable_woocommerce_scripts_and_styles() {
        if (function_exists('is_woocommerce') && (is_woocommerce() || is_cart() || is_checkout())) {
            wp_dequeue_style('woocommerce-layout');
            wp_dequeue_style('woocommerce-smallscreen');
            wp_dequeue_style('woocommerce-general');
            wp_dequeue_script('wc-cart-fragments');
        }
    }

    public function disable_woocommerce_blocks() {
        wp_dequeue_style('wc-blocks-style');
        wp_dequeue_script('wc-blocks');
    }
}
?>