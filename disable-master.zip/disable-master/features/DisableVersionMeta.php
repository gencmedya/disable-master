<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableVersionMeta {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_version_meta']) && $options['disable_version_meta']) {
            remove_action('wp_head', 'wp_generator');
        }
    }
}
?>