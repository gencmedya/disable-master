<?php
namespace DisableMaster\Features;

class DisableRightClickAndSelection {
    public function __construct() {
        add_action('wp_footer', [$this, 'disable_right_click_and_selection']);
    }

    public function disable_right_click_and_selection() {
        $options = get_option('disable_master_options');
        if (is_array($options) && isset($options['disable_right_click_and_selection']) && $options['disable_right_click_and_selection']) {
            echo '<script type="text/javascript">
                document.addEventListener("contextmenu", function(e) {
                    e.preventDefault();
                });
                document.addEventListener("selectstart", function(e) {
                    e.preventDefault();
                });
            </script>';
        }
    }
}
?>