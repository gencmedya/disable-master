<?php
namespace DisableMaster\Features;

class DisableXMLRPCPingbacks {
    public function __construct() {
        add_action('init', [$this, 'init']);
        add_filter('xmlrpc_enabled', '__return_false');
        add_filter('wp_headers', [$this, 'remove_x_pingback']);
        add_filter('pings_open', '__return_false', 10, 1);
        add_filter('bloginfo_url', [$this, 'remove_pingback_url'], 10, 2);
        add_filter('xmlrpc_methods', [$this, 'disable_pingbacks']);
        add_action('template_redirect', [$this, 'block_xmlrpc_requests']);
        add_action('xmlrpc_call', [$this, 'block_xmlrpc_requests']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_xmlrpc_pingbacks']) && $options['disable_xmlrpc_pingbacks']) {
            // Block XML-RPC requests
            add_action('template_redirect', [$this, 'block_xmlrpc_requests']);
            add_action('xmlrpc_call', [$this, 'block_xmlrpc_requests']);
        } else {
            // Re-enable XML-RPC if option is unchecked
            remove_action('template_redirect', [$this, 'block_xmlrpc_requests']);
            remove_action('xmlrpc_call', [$this, 'block_xmlrpc_requests']);
        }
    }

    public function remove_x_pingback($headers) {
        unset($headers['X-Pingback']);
        return $headers;
    }

    public function remove_pingback_url($output, $show) {
        if ($show == 'pingback_url') {
            $output = '';
        }
        return $output;
    }

    public function disable_pingbacks($methods) {
        unset($methods['pingback.ping']);
        return $methods;
    }

    public function block_xmlrpc_requests() {
        if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
            status_header(403);
            wp_die('XML-RPC services are disabled on this site.', 'XML-RPC Disabled', array('response' => 403));
        }
    }
}
?>
