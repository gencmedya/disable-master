<?php
namespace DisableMaster\Features;

class DisableSiteHealth {
    public function __construct() {
        add_action('admin_menu', [$this, 'remove_site_health_menu'], 999);
        add_action('wp_dashboard_setup', [$this, 'remove_site_health_dashboard_widget']);
        add_filter('site_status_tests', [$this, 'remove_site_health_checks']);
        add_action('admin_enqueue_scripts', [$this, 'hide_site_health_menu']);
        add_action('load-tools_page_site-health', [$this, 'block_site_health_page']);
    }

    public function remove_site_health_menu() {
        // Site Sağlığı menü öğesini kaldır
        remove_submenu_page('tools.php', 'site-health.php');
    }

    public function remove_site_health_checks($tests) {
        // Site Sağlığı kontrollerini devre dışı bırak
        return [];
    }

    public function remove_site_health_dashboard_widget() {
        // Site Sağlığı widget'ını kaldır
        remove_meta_box('dashboard_site_health', 'dashboard', 'normal');
    }

    public function hide_site_health_menu() {
        // Site Sağlığı menüsünü CSS ile gizle
        echo '<style>#menu-tools .wp-submenu a[href="site-health.php"] { display: none; }</style>';
    }

    public function block_site_health_page() {
        // 'site-health.php' sayfasını engelle
        wp_die(esc_html__('Site Health is disabled.', 'disable-master'), '', array('response' => 403));
    }
}
?>
