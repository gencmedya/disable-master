<?php
namespace DisableMaster\Features;

class DisableMediaSizes {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (is_array($options) && isset($options['disable_media_sizes']) && $options['disable_media_sizes']) {
            add_filter('intermediate_image_sizes', [$this, 'remove_media_sizes']);
        }
    }

    public function remove_media_sizes($sizes) {
        return array();
    }
}
?>