<?php
namespace DisableMaster\Features;

class DisableHtmlComments {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (is_array($options) && isset($options['disable_html_comments']) && $options['disable_html_comments']) {
            add_action('template_redirect', [$this, 'start_buffer']);
        }
    }

    public function start_buffer() {
        ob_start([$this, 'remove_html_comments']);
    }

    public function remove_html_comments($buffer) {
        // HTML yorumlarını kaldır
        return preg_replace('/<!--(.|\s)*?-->/', '', $buffer);
    }
}
?>