<?php
namespace DisableMaster\Features;

class DisableHeartbeat {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_heartbeat']) && $options['disable_heartbeat']) {
            wp_deregister_script('heartbeat');
        }
    }
}
?>