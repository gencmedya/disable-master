<?php
namespace DisableMaster\Features;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class DisableThemeUpdates {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_theme_updates']) && $options['disable_theme_updates']) {
            add_filter('auto_update_theme', '__return_false');
            add_filter('site_transient_update_themes', '__return_null');
            add_filter('transient_update_themes', '__return_null');
            add_filter('theme_action_links', [$this, 'remove_update_action']);

            add_action('wp_before_admin_bar_render', [$this, 'disable_admin_bar_updates']);
            add_action('admin_menu', [$this, 'disable_admin_menu_updates'], 999);
            add_action('admin_init', [$this, 'redirect_theme_update_pages']);
            add_action('admin_menu', [$this, 'disable_update_notifications']);
        }
    }

    public function remove_update_action($actions) {
        unset($actions['update']);
        return $actions;
    }

    public function disable_admin_bar_updates() {
        global $wp_admin_bar;
        $wp_admin_bar->remove_menu('updates');
    }

    public function disable_admin_menu_updates() {
        remove_submenu_page('themes.php', 'theme-install.php');
        remove_submenu_page('themes.php', 'theme-editor.php');
    }

    public function redirect_theme_update_pages() {
        global $pagenow;
        if ($pagenow === 'update-core.php' || $pagenow === 'update.php') {
            wp_redirect(admin_url());
            exit;
        }
    }

    public function disable_update_notifications() {
        remove_action('admin_notices', 'update_nag', 3);
    }
}
?>