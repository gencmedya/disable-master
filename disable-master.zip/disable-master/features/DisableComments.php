<?php
namespace DisableMaster\Features;

class DisableComments {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');

        if (isset($options['disable_comments']) && $options['disable_comments']) {
            if (is_admin()) {
                add_action('admin_menu', [$this, 'disable_comments_admin_menu']);
                add_action('admin_init', [$this, 'disable_comments_admin_init']);
                add_action('admin_init', [$this, 'disable_comments_admin_bar']);
                add_action('admin_print_styles-index.php', [$this, 'disable_comments_admin_styles']);
                add_action('admin_print_styles-profile.php', [$this, 'disable_comments_admin_styles']);
                add_action('admin_init', [$this, 'disable_comments_remove_meta_boxes']);
            } else {
                add_filter('comments_open', '__return_false', 20, 2);
                add_filter('pings_open', '__return_false', 20, 2);
                add_filter('comments_array', '__return_empty_array', 10, 2);

                // Yorumları tamamen kaldır
                add_filter('comments_template', [$this, 'disable_comments_template'], 20);
                add_action('wp_enqueue_scripts', [$this, 'disable_comments_css']);

                // Yorum bağlantılarını ve öğelerini gizle
                add_action('wp_head', function() {
                    echo '<style>
                        .entry-comments-link,
                        .comments-area,
                        .comments-link,
                        .comments-count,
                        #comments,
                        .comment-reply-link,
                        .comment-respond {
                            display: none !important;
                        }
                    </style>';
                });

                // Nonce kullanarak yorum spamini engelle
                add_action('pre_comment_on_post', [$this, 'disable_comments_verify_nonce']);
            }

            add_action('admin_notices', [$this, 'disable_comments_last_notice']);
        } else {
            // Yorumları yeniden etkinleştir
            remove_action('admin_menu', [$this, 'disable_comments_admin_menu']);
            remove_action('admin_init', [$this, 'disable_comments_admin_init']);
            remove_action('admin_init', [$this, 'disable_comments_admin_bar']);
            remove_action('admin_print_styles-index.php', [$this, 'disable_comments_admin_styles']);
            remove_action('admin_print_styles-profile.php', [$this, 'disable_comments_admin_styles']);
            remove_action('admin_init', [$this, 'disable_comments_remove_meta_boxes']);
            remove_filter('comments_open', '__return_false', 20);
            remove_filter('pings_open', '__return_false', 20);
            remove_filter('comments_array', '__return_empty_array', 10);
            remove_filter('comments_template', [$this, 'disable_comments_template'], 20);
            remove_action('wp_enqueue_scripts', [$this, 'disable_comments_css']);
            remove_action('admin_notices', [$this, 'disable_comments_last_notice']);
            remove_action('pre_comment_on_post', [$this, 'disable_comments_verify_nonce']);
        }
    }

    public function disable_comments_admin_menu() {
        remove_menu_page('edit-comments.php');
    }

    public function disable_comments_admin_init() {
        global $pagenow;

        if ($pagenow === 'edit-comments.php' || $pagenow === 'options-discussion.php') {
            wp_redirect(admin_url());
            exit;
        }
    }

    public function disable_comments_admin_bar() {
        remove_action('admin_bar_menu', 'wp_admin_bar_comments_menu', 60);
    }

    public function disable_comments_admin_styles() {
        echo '<style>
            #dashboard_right_now .comment-count,
            #dashboard_right_now .comment-mod-count {
                display: none;
            }
        </style>';
    }

    public function disable_comments_remove_meta_boxes() {
        remove_meta_box('commentstatusdiv', 'post', 'normal'); // Yorumlar
        remove_meta_box('commentsdiv', 'post', 'normal'); // Tartışma
        remove_meta_box('commentstatusdiv', 'page', 'normal'); // Yorumlar
        remove_meta_box('commentsdiv', 'page', 'normal'); // Tartışma
    }

    public function disable_comments_last_notice() {
        echo '<div class="error"><p>' . esc_html__('Comments are closed.', 'disable-master-plugin') . '</p></div>';
    }

    public function disable_comments_template($file) {
        return dirname(__FILE__) . '/empty-comments-template.php';
    }

    public function disable_comments_css() {
        echo '<style>
            .comments-area, .g1-comments, .comment-form { display: none !important; }
            .entry-comments-link,
            .comments-area,
            .comments-link,
            .comments-count,
            #comments,
            .comment-reply-link,
            .comment-respond {
                display: none !important;
            }
        </style>';
    }

    // Yorum spamini engellemek için nonce doğrulaması ekleyelim
    public function disable_comments_verify_nonce() {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'disable-comments')) {
            wp_die(esc_html__('Yorum gönderme işlemi geçersiz.', 'disable-master-plugin'));
        }
    }

    // Yorum formuna nonce eklemek için
    public function disable_comments_add_nonce_to_comment_form() {
        if (is_singular() && comments_open()) {
            wp_nonce_field('disable-comments', '_wpnonce', true, true);
        }
    }
}
?>