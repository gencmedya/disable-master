<?php
namespace DisableMaster\Features;

class DisableAuthorPages {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        $options = get_option('disable_master_options');
        if (isset($options['disable_author_pages']) && $options['disable_author_pages']) {
            add_action('template_redirect', [$this, 'redirect_author_pages']);
        }
    }

    public function redirect_author_pages() {
        if (is_author()) {
            wp_redirect(home_url());
            exit;
        }
    }
}
?>