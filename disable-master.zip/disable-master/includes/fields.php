<?php
namespace DisableMaster;

if (!defined('ABSPATH')) {
    exit; // Doğrudan erişimi engelle
}

class Fields {
    public static function get_fields() {
        return [
            'disable_gutenberg' => [
                'label' => __('Disable Gutenberg Editor', 'disable-master'),
                'description' => __('Gutenberg editor is disabled, and the classic editor is used. Useful if you find it difficult to adapt to Gutenberg or prefer the classic editor.', 'disable-master'),
            ],
            'disable_comments' => [
                'label' => __('Disable Comments', 'disable-master'),
                'description' => __('Comments are disabled on all posts and pages. Useful if you do not want to receive comments or to prevent spam.', 'disable-master'),
            ],
            'disable_emojis' => [
                'label' => __('Disable Emojis', 'disable-master'),
                'description' => __('Emoji script is disabled. This can speed up the loading time of your site.', 'disable-master'),
            ],
            'disable_embeds' => [
                'label' => __('Disable Embeds', 'disable-master'),
                'description' => __('Disable the oEmbed functionality.', 'disable-master'),
            ],
            'disable_xmlrpc_pingbacks' => [
                'label' => __('Disable XML-RPC & Pingbacks', 'disable-master'),
                'description' => __('XML-RPC protocol and pingback functionality are disabled. This can prevent external services from communicating with your site via XML-RPC and enhance security.', 'disable-master'),
            ],
            'disable_rest_api' => [
                'label' => __('Disable REST API', 'disable-master'),
                'description' => __('WordPress REST API is disabled. This can enhance security and reduce issues related to external access.', 'disable-master'),
            ],
            'disable_author_pages' => [
                'label' => __('Disable Author Pages', 'disable-master'),
                'description' => __('Author archive pages are disabled. Useful for reducing unnecessary pages and keeping your site organized.', 'disable-master'),
            ],
            'disable_feed' => [
                'label' => __('Disable Feed', 'disable-master'),
                'description' => __('RSS feed functionality is disabled. Disable if you do not need feeds on your site.', 'disable-master'),
            ],
            'disable_post_formats' => [
                'label' => __('Disable Post Formats', 'disable-master'),
                'description' => __('Post format support is disabled. Useful for keeping posts in a standard format.', 'disable-master'),
            ],
            'disable_revisions' => [
                'label' => __('Disable Revisions', 'disable-master'),
                'description' => __('Post revisions are disabled. This can reduce database load and improve performance.', 'disable-master'),
            ],
            'disable_autosave' => [
                'label' => __('Disable Autosave', 'disable-master'),
                'description' => __('Autosave feature is disabled. This can reduce database load and improve performance.', 'disable-master'),
            ],
            'disable_search' => [
                'label' => __('Disable Search', 'disable-master'),
                'description' => __('Search functionality is disabled. Useful for simplifying user experience if you do not need search on your site.', 'disable-master'),
            ],
            'disable_widgets' => [
                'label' => __('Disable Widgets', 'disable-master'),
                'description' => __('All widgets and sidebars are disabled. This can improve performance and remove unnecessary elements.', 'disable-master'),
            ],
            'disable_dashboard_widgets' => [
                'label' => __('Disable Dashboard Widgets', 'disable-master'),
                'description' => __('Dashboard widgets are disabled. This simplifies the dashboard and improves performance.', 'disable-master'),
            ],
            'disable_self_pings' => [
                'label' => __('Disable Self Pings', 'disable-master'),
                'description' => __('Self pings are disabled. This can reduce unnecessary server load.', 'disable-master'),
            ],
            'disable_trackbacks' => [
                'label' => __('Disable Trackbacks', 'disable-master'),
                'description' => __('Disable trackbacks.', 'disable-master'),
            ],
            'disable_rss_feeds' => [
                'label' => __('Disable RSS Feeds', 'disable-master'),
                'description' => __('Disable RSS feeds.', 'disable-master'),
            ],
            'disable_sitemaps' => [
                'label' => __('Disable Sitemaps', 'disable-master'),
                'description' => __('Default WordPress sitemaps are disabled. Useful if you are using an external sitemap.', 'disable-master'),
            ],
            'disable_login_errors' => [
                'label' => __('Disable Login Errors', 'disable-master'),
                'description' => __('Login error messages are hidden. This can enhance security.', 'disable-master'),
            ],
            'disable_file_editor' => [
                'label' => __('Disable File Editor', 'disable-master'),
                'description' => __('Theme and plugin file editor is disabled. This can enhance security.', 'disable-master'),
            ],
            'disable_user_registration' => [
                'label' => __('Disable User Registration', 'disable-master'),
                'description' => __('User registration form is disabled. Useful if you want to limit user registrations.', 'disable-master'),
            ],
            'disable_admin_bar' => [
                'label' => __('Disable Admin Bar', 'disable-master'),
                'description' => __('Admin bar is disabled for all users. Useful for simplifying user experience.', 'disable-master'),
            ],
            'disable_version_meta' => [
                'label' => __('Disable Version Meta', 'disable-master'),
                'description' => __('WordPress version meta tag is removed. This can enhance security.', 'disable-master'),
            ],
            'disable_wp_generator' => [
                'label' => __('Disable WP Generator', 'disable-master'),
                'description' => __('WordPress generator tag is removed. This can enhance security.', 'disable-master'),
            ],
            'disable_admin_ajax' => [
                'label' => __('Disable admin-ajax.php on Front-End', 'disable-master'),
                'description' => __('admin-ajax.php is disabled on the front-end to improve performance.', 'disable-master'),
            ],
            'disable_query_strings' => [
                'label' => __('Remove Query Strings from Static Resources', 'disable-master'),
                'description' => __('Query strings are removed from static resources to improve caching and performance.', 'disable-master'),
            ],
            'disable_heartbeat' => [
                'label' => __('Disable or Limit Heartbeat API', 'disable-master'),
                'description' => __('Disable or limit the WordPress Heartbeat API.', 'disable-master'),
                'type' => 'select',
                'options' => [
                    '' => __('None', 'disable-master'),
                    'disable' => __('Disable', 'disable-master'),
                    'limit' => __('Limit', 'disable-master')
                ]
            ],
            'disable_tags' => [
                'label' => __('Disable Tags', 'disable-master'),
                'description' => __('Tag functionality is disabled. Useful for simplifying content management.', 'disable-master'),
            ],
            'disable_core_updates' => [
                'label' => __('Disable Core Updates', 'disable-master'),
                'description' => __('WordPress core updates are disabled. Useful if you prefer to check for updates manually.', 'disable-master'),
            ],
            'disable_plugin_updates' => [
                'label' => __('Disable Plugin Updates', 'disable-master'),
                'description' => __('Plugin updates are disabled. Useful if you prefer to check for updates manually.', 'disable-master'),
            ],
            'disable_theme_updates' => [
                'label' => __('Disable Theme Updates', 'disable-master'),
                'description' => __('Theme updates are disabled. Useful if you prefer to check for updates manually.', 'disable-master'),
            ],
            'disable_dashboard' => [
                'label' => __('Disable Dashboard', 'disable-master'),
                'description' => __('WordPress dashboard is disabled. Useful if you do not use the dashboard or want to restrict access.', 'disable-master'),
            ],
            'disable_source' => [
                'label' => __('Disable Source', 'disable-master'),
                'description' => __('Disable source code view.', 'disable-master'),
            ],
            'disable_right_click_and_selection' => [
                'label' => __('Disable Right Click and Text Selection', 'disable-master'),
                'description' => __('Right click and text selection are disabled to prevent content copying.', 'disable-master'),
            ],
            'disable_admin_notices' => [
                'label' => __('Disable Admin Notices', 'disable-master'),
                'description' => __('Admin notices are disabled. This simplifies the admin panel.', 'disable-master'),
            ],
            'disable_wp_notification' => [
                'label' => __('Disable WP Notification', 'disable-master'),
                'description' => __('WordPress notifications are disabled. This simplifies the admin panel.', 'disable-master'),
            ],
            'disable_media_sizes' => [
                'label' => __('Disable Media Sizes', 'disable-master'),
                'description' => __('Additional media sizes are disabled. This can optimize disk space and performance.', 'disable-master'),
            ],
            'disable_woocommerce' => [
                'label' => __('Disable WooCommerce', 'disable-master'),
                'description' => __('WooCommerce functionality is disabled. Useful if you want to temporarily disable WooCommerce.', 'disable-master'),
            ],
            'disable_application_passwords' => [
                'label' => __('Disable Application Passwords', 'disable-master'),
                'description' => __('Application passwords are disabled to enhance security.', 'disable-master'),
            ],
            'disable_html_comments' => [
                'label' => __('Disable HTML Comments', 'disable-master'),
                'description' => __('HTML comments are disabled. This can simplify HTML source code and enhance security.', 'disable-master'),
            ],
            'disable_api_request_logging' => [
                'label' => __('Disable API Request Logging', 'disable-master'),
                'description' => __('Disable logging of API requests to reduce server load.', 'disable-master'),
            ],
            'disable_wp_cron' => [
                'label' => __('Disable WP-Cron and Use Real Cron Jobs', 'disable-master'),
                'description' => __('Disable WP-Cron and use real cron jobs for more efficient scheduled tasks.', 'disable-master'),
            ],
            'disable_post_locking' => [
                'label' => __('Disable Post Locking', 'disable-master'),
                'description' => __('Disable post locking feature to simplify user experience for single-author sites.', 'disable-master'),
            ],
            'disable_uploads' => [
                'label' => __('Disable Uploads', 'disable-master'),
                'description' => __('Disable the ability to upload media, themes, and plugins.', 'disable-master'),
            ],
            'disable_site_health' => [
                'label' => __('Disable Site Health', 'disable-master'),
                'description' => __('Disables Site Health checks to reduce load and simplify the admin interface.', 'disable-master'),
            ],
        ];
    }
}
?>
