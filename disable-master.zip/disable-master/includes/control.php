<?php
/**
 * Control Page for Disable Master
 * 
 * This page allows you to monitor and manage potential conflicts and issues
 * related to the Disable Master plugin. You can manually run checks for 
 * conflicts with themes and other plugins, and clear the log file as needed.
 */

function disable_master_control_page_html() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Log dosyasını okuma ve gösterme
    $log_file = plugin_dir_path(__FILE__) . '../log.txt';
    $log_content = '';
    if (file_exists($log_file)) {
        $log_content = disable_master_read_log_file($log_file);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_admin_referer('disable_master_control_nonce_action', 'disable_master_control_nonce');

        if (isset($_POST['clear_log'])) {
            disable_master_clear_log($log_file);
            $log_content = '';
        } elseif (isset($_POST['run_checks'])) {
            disable_master_check_conflicts();
            $log_content = disable_master_read_log_file($log_file);
        }
    }

    ?>
    <div class="wrap">
        <h1><?php esc_html_e('System Check', 'disable-master'); ?></h1>
        <p><?php esc_html_e('This page allows you to monitor and manage potential conflicts and issues related to the Disable Master plugin.', 'disable-master'); ?></p>
        <p><?php esc_html_e('You can manually run checks for conflicts with themes and other plugins, and clear the log file as needed.', 'disable-master'); ?></p>
        <form method="post">
            <?php wp_nonce_field('disable_master_control_nonce_action', 'disable_master_control_nonce'); ?>
            <textarea rows="20" cols="100" readonly><?php echo esc_textarea($log_content); ?></textarea><br>
            <button type="submit" name="clear_log" class="button button-secondary"><?php esc_html_e('Clear Log', 'disable-master'); ?></button>
            <button type="submit" name="run_checks" class="button button-primary"><?php esc_html_e('Run Checks', 'disable-master'); ?></button>
        </form>
    </div>
    <?php
}

// Log dosyasını oku
function disable_master_read_log_file($log_file) {
    global $wp_filesystem;
    if (empty($wp_filesystem)) {
        require_once(ABSPATH . '/wp-admin/includes/file.php');
        WP_Filesystem();
    }
    return $wp_filesystem->get_contents($log_file);
}

// Log dosyasını temizle
function disable_master_clear_log($log_file) {
    global $wp_filesystem;
    if (empty($wp_filesystem)) {
        require_once(ABSPATH . '/wp-admin/includes/file.php');
        WP_Filesystem();
    }
    $wp_filesystem->put_contents($log_file, '', FS_CHMOD_FILE);
}

// Log ekleme işlevi
function disable_master_add_log($message) {
    global $wp_filesystem;
    if (empty($wp_filesystem)) {
        require_once(ABSPATH . '/wp-admin/includes/file.php');
        WP_Filesystem();
    }
    
    $log_file = plugin_dir_path(__FILE__) . '../log.txt';
    $time = gmdate('Y-m-d H:i:s');
    $log_message = "[{$time}] {$message}\n";
    
    // Mevcut log içeriğini oku ve yeni log mesajını ekle
    if (file_exists($log_file)) {
        $existing_logs = $wp_filesystem->get_contents($log_file);
        $log_message = $existing_logs . $log_message;
    }
    
    $wp_filesystem->put_contents($log_file, $log_message, FS_CHMOD_FILE);
}

// Çakışma ve hata kontrolleri
function disable_master_check_conflicts() {
    $conflicts = [];

    // WordPress sürümü kontrolü
    global $wp_version;
    if (version_compare($wp_version, '5.0', '<')) {
        $conflicts[] = __('WordPress version is below 5.0, which may cause conflicts with Disable Master.', 'disable-master');
    }

    // Etkin olan tüm eklentileri kontrol et
    $active_plugins = get_option('active_plugins');
    foreach ($active_plugins as $plugin) {
        if (strpos($plugin, 'conflicting-plugin-folder/conflicting-plugin-file.php') !== false) {
            // translators: %s: Plugin name
            $conflicts[] = sprintf(__('Conflicting Plugin detected: %s', 'disable-master'), esc_html($plugin));
        }
    }

    // Etkin olan tema kontrolü
    $current_theme = wp_get_theme();
    if ($current_theme->get('Name') == 'Conflicting Theme') {
        // translators: %s: Theme name
        $conflicts[] = sprintf(__('Conflicting Theme detected: %s', 'disable-master'), esc_html($current_theme->get('Name')));
    }

    // Çakışma ve hata raporlarını log dosyasına yazdır
    if (!empty($conflicts)) {
        foreach ($conflicts as $conflict) {
            disable_master_add_log($conflict);
        }
    } else {
        disable_master_add_log(__('No conflicts detected.', 'disable-master'));
    }
}
?>
