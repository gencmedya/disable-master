jQuery(document).ready(function($) {
    $('#info-button').on('click', function() {
        $('#info-popup').css('display', 'flex');
    });

    $('#close-popup').on('click', function() {
        $('#info-popup').css('display', 'none');
    });

    $(document).on('click', function(event) {
        if (!$(event.target).closest('#info-popup, #info-button').length) {
            $('#info-popup').css('display', 'none');
        }
    });

    $('.disable-master-form input[type="checkbox"]').on('change', function() {
        $('#save-button').prop('disabled', false);
    });
});
