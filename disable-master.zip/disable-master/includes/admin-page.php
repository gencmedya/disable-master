<?php
function disable_master_admin_page() {
    add_menu_page(
        __('Disable Master Settings', 'disable-master'),
        __('Disable Master', 'disable-master'),
        'manage_options',
        'disable-master',
        'disable_master_admin_page_html',
        'dashicons-admin-generic',
        3
    );
}
add_action('admin_menu', 'disable_master_admin_page');

function disable_master_admin_page_html() {
    if (!current_user_can('manage_options')) {
        return;
    }
    wp_enqueue_style('disable-master-admin-styles', plugin_dir_url(__FILE__) . 'admin-styles.css', array(), '1.0.0');
    wp_enqueue_script('disable-master-admin-script', plugin_dir_url(__FILE__) . 'admin-scripts.js', array('jquery'), '1.0.0', true);

    // Create nonce
    $nonce = wp_create_nonce('disable_master_nonce');

    // Include fields.php and get fields
    require_once plugin_dir_path(__FILE__) . '/fields.php';
    $fields = \DisableMaster\Fields::get_fields();

    // Get plugin version
    $plugin_data = get_file_data(plugin_dir_path(__FILE__) . '../disable-master.php', array('Version' => 'Version'), 'plugin');
    $plugin_version = 'v' . $plugin_data['Version'];

    $buy_me_a_coffee_text = __('Buy Me a Coffee', 'disable-master');
    $buy_me_a_coffee_url = __('https://img.buymeacoffee.com/button-api/?text=Buy%20Me%20a%20Coffee%C2%A0&emoji=&slug=gencmedya&button_colour=FF5F5F&font_colour=ffffff&font_family=Cookie&outline_colour=000000&coffee_colour=FFDD00', 'disable-master');
    ?>
    <div class="disable-master-settings-wrap">
        <div class="disable-master-toolbar">
            <div class="disable-master-title">
                <h1><?php esc_html_e('Disable Master Settings', 'disable-master'); ?></h1>
                <label class="switch toggle-all-switch" style="margin-left: 20px;">
                    <input type="checkbox" id="toggle-all" />
                    <span class="slider round" title="<?php esc_attr_e('Toggle All', 'disable-master'); ?>"></span>
                </label>
            </div>
            <div class="disable-master-toolbar-buttons">
                <button id="info-button" class="button button-secondary"><?php esc_html_e('Info', 'disable-master'); ?></button>
                <input type="submit" form="disable-master-form" id="save-button" class="button button-primary disable-master-save-button" value="<?php esc_attr_e('Save', 'disable-master'); ?>" disabled />
            </div>
        </div>
        <div id="info-popup" class="disable-master-popup">
            <div class="disable-master-popup-content">
                <span class="disable-master-popup-version"><?php echo esc_html($plugin_version); ?></span>
                <span id="close-popup" class="disable-master-popup-close">&times;</span>
                <div style="text-align: center;">
                    <script src="https://unpkg.com/@dotlottie/player-component@latest/dist/dotlottie-player.mjs" type="module"></script>
                    <dotlottie-player src="https://lottie.host/1ea48114-865b-4ea2-a527-fa0b96934855/KAAogLiIGm.json" background="transparent" speed="1" style="width: 270px; height: 200px; margin: 0 auto;" direction="1" playMode="normal" loop autoplay></dotlottie-player>
                </div>
                <p><?php esc_html_e('A comprehensive plugin to disable various WordPress functionalities.', 'disable-master'); ?></p>
                <p><?php esc_html_e('If you want to add more features to the plugin or report bugs, please email halil@gencmedya.com.', 'disable-master'); ?></p>
                <p><?php esc_html_e('To follow more features, visit', 'disable-master'); ?> <a href="https://wordpress.org/plugins/disable-master" target="_blank">wordpress.org/plugins/disable-master</a> <?php esc_html_e('or', 'disable-master'); ?> <a href="https://gencmedya.com" target="_blank">gencmedya.com</a>.</p>
                <p><?php esc_html_e('Configure the options to disable various WordPress functionalities.', 'disable-master'); ?></p>
                <div style="text-align: center;">
                    <a href="https://buymeacoffee.com/gencmedya" target="_blank">
                        <img src="<?php echo esc_url($buy_me_a_coffee_url); ?>" alt="<?php echo esc_attr($buy_me_a_coffee_text); ?>">
                    </a>
                </div>
            </div>
        </div>
        <form method="post" action="options.php" id="disable-master-form" class="disable-master-form">
            <?php
            // Add nonce field
            wp_nonce_field('disable_master_action', 'disable_master_nonce');
            settings_fields('disable_master_settings');
            do_settings_sections('disable-master');
            ?>
            <div class="disable-master-settings-grid">
                <?php
                foreach ($fields as $field => $data) {
                    $options = get_option('disable_master_options');
                    $checked = isset($options[$field]) ? 'checked' : '';
                    $title = $checked ? __('Disable', 'disable-master') : __('Enable', 'disable-master');
                    ?>
                    <div class="disable-master-box">
                        <h2><?php echo esc_html($data['label'], 'disable-master'); ?></h2>
                        <p><?php echo esc_html($data['description'], 'disable-master'); ?></p>
                        <label class="switch">
                            <input type="checkbox" class="feature-toggle" id="<?php echo esc_attr($field); ?>" name="disable_master_options[<?php echo esc_attr($field); ?>]" value="1" <?php echo esc_attr($checked); ?>>
                            <span class="slider round" title="<?php echo esc_attr($title); ?>"></span>
                        </label>
                    </div>
                    <?php
                }
                ?>
            </div>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const toggleAllCheckbox = document.getElementById('toggle-all');
            const featureToggles = document.querySelectorAll('.feature-toggle');
            const toggleAllTitle = toggleAllCheckbox.closest('.toggle-all-switch').querySelector('.slider');

            function updateToggleAllTitle() {
                if (toggleAllCheckbox.checked) {
                    toggleAllTitle.setAttribute('title', '<?php echo esc_attr__('Turn Off All', 'disable-master'); ?>');
                } else {
                    toggleAllTitle.setAttribute('title', '<?php echo esc_attr__('Turn On All', 'disable-master'); ?>');
                }
            }

            toggleAllCheckbox.addEventListener('change', function () {
                const isChecked = toggleAllCheckbox.checked;
                featureToggles.forEach(function (checkbox) {
                    checkbox.checked = isChecked;
                    updateFeatureToggleTitle(checkbox);
                });
                document.getElementById('save-button').disabled = false;
                if (isChecked) {
                    toggleAllCheckbox.closest('.toggle-all-switch').querySelector('.slider').style.backgroundColor = 'orange';
                } else {
                    toggleAllCheckbox.closest('.toggle-all-switch').querySelector('.slider').style.backgroundColor = '';
                }
                updateToggleAllTitle();
            });

            featureToggles.forEach(function (checkbox) {
                checkbox.addEventListener('change', function () {
                    document.getElementById('save-button').disabled = false;
                    updateFeatureToggleTitle(checkbox);
                });
            });

            function updateFeatureToggleTitle(checkbox) {
                const slider = checkbox.nextElementSibling;
                if (checkbox.checked) {
                    slider.setAttribute('title', '<?php echo esc_attr__('Disable', 'disable-master'); ?>');
                } else {
                    slider.setAttribute('title', '<?php echo esc_attr__('Enable', 'disable-master'); ?>');
                }
            }

            featureToggles.forEach(function (checkbox) {
                updateFeatureToggleTitle(checkbox);
            });

            updateToggleAllTitle(); // Update title on page load
        });

        jQuery(document).ready(function($) {
            $('#info-button').on('click', function() {
                $('#info-popup').css('display', 'flex');
            });

            $('#close-popup').on('click', function() {
                $('#info-popup').css('display', 'none');
            });

            $(document).on('click', function(event) {
                if (!$(event.target).closest('#info-popup, #info-button').length) {
                    $('#info-popup').css('display', 'none');
                }
            });

            $('.disable-master-form input[type="checkbox"]').on('change', function() {
                $('#save-button').prop('disabled', false);
            });
        });
    </script>
    <?php
}

function disable_master_settings_init() {
    register_setting('disable_master_settings', 'disable_master_options');

    add_settings_section(
        'disable_master_section',
        '', // Title parameter is left empty
        null,
        'disable-master'
    );
}
add_action('admin_init', 'disable_master_settings_init');
?>
