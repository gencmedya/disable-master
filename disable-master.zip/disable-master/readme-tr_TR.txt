=== Disable Master ===
Contributors: gencmedya
Tags: devre dışı bırakma, işlevler, güvenlik, optimizasyon, hız
Requires at least: 5.0
Tested up to: 6.5.3
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Çeşitli WordPress işlevlerini devre dışı bırakmak için kapsamlı bir eklenti.

== Açıklama ==

Disable Master, güvenliği, performansı ve kullanıcı deneyimini artırmak için çeşitli WordPress işlevlerini devre dışı bırakmanıza olanak tanıyan kapsamlı bir eklentidir. Kullanılmayan özellikleri kolayca devre dışı bırakarak WordPress sitenizi optimize edin.

**Özellikler:**

- **Gutenberg Editörünü Devre Dışı Bırak**
  - Devre Dışı: Gutenberg editörü kullanılır.
  - Etkin: Gutenberg editörü devre dışı bırakılır ve klasik editör kullanılır. Gutenberg'e uyum sağlamakta zorlanıyorsanız veya klasik editörü tercih ediyorsanız kullanışlıdır.

- **Yorumları Devre Dışı Bırak**
  - Devre Dışı: Yorumlar etkin kalır.
  - Etkin: Tüm yazı ve sayfalardaki yorumlar devre dışı bırakılır. Yorum almak istemiyorsanız veya spam'ı önlemek istiyorsanız kullanışlıdır.

- **Emojileri Devre Dışı Bırak**
  - Devre Dışı: WordPress tarafından eklenen emoji scripti kullanılır.
  - Etkin: Emoji scripti devre dışı bırakılır. Bu, sitenizin yükleme süresini hızlandırabilir.

- **XML-RPC ve Geri İzlemeleri Devre Dışı Bırak**
  - Devre Dışı: XML-RPC ve geri izleme işlevselliği etkin kalır.
  - Etkin: XML-RPC protokolü ve geri izleme işlevselliği devre dışı bırakılır. Bu, dış hizmetlerin sitenizle XML-RPC aracılığıyla iletişim kurmasını engelleyebilir ve güvenliği artırabilir.

- **REST API'yi Devre Dışı Bırak**
  - Devre Dışı: WordPress REST API etkin kalır.
  - Etkin: WordPress REST API devre dışı bırakılır. Bu, güvenliği artırabilir ve dış erişimle ilgili sorunları azaltabilir.

- **Yazar Sayfalarını Devre Dışı Bırak**
  - Devre Dışı: Yazar arşiv sayfaları etkin kalır.
  - Etkin: Yazar arşiv sayfaları devre dışı bırakılır. Gereksiz sayfaları azaltmak ve sitenizi düzenli tutmak için kullanışlıdır.

- **RSS Beslemelerini Devre Dışı Bırak**
  - Devre Dışı: RSS besleme işlevselliği etkin kalır.
  - Etkin: RSS besleme işlevselliği devre dışı bırakılır. Sitenizde beslemelere ihtiyaç duymuyorsanız devre dışı bırakın.

- **Yazı Formatlarını Devre Dışı Bırak**
  - Devre Dışı: Yazı formatı desteği etkin kalır.
  - Etkin: Yazı formatı desteği devre dışı bırakılır. Yazıları standart bir formatta tutmak için kullanışlıdır.

- **Sürüm Geçmişlerini Devre Dışı Bırak**
  - Devre Dışı: Yazı sürümleri etkin kalır.
  - Etkin: Yazı sürümleri devre dışı bırakılır. Bu, veritabanı yükünü azaltabilir ve performansı artırabilir.

- **Otomatik Kaydetmeyi Devre Dışı Bırak**
  - Devre Dışı: Otomatik kaydetme özelliği etkin kalır.
  - Etkin: Otomatik kaydetme özelliği devre dışı bırakılır. Bu, veritabanı yükünü azaltabilir ve performansı artırabilir.

- **Aramayı Devre Dışı Bırak**
  - Devre Dışı: Arama işlevselliği etkin kalır.
  - Etkin: Arama işlevselliği devre dışı bırakılır. Sitenizde aramaya ihtiyaç duymuyorsanız kullanıcı deneyimini basitleştirmek için kullanışlıdır.

- **Kendi Kendine Geri İzlemeleri Devre Dışı Bırak**
  - Devre Dışı: Kendi kendine geri izlemeler etkin kalır.
  - Etkin: Kendi kendine geri izlemeler devre dışı bırakılır. Bu, gereksiz sunucu yükünü azaltabilir.

- **Sitemaps'leri Devre Dışı Bırak**
  - Devre Dışı: Varsayılan WordPress sitemaps'leri etkin kalır.
  - Etkin: Varsayılan WordPress sitemaps'leri devre dışı bırakılır. Harici bir sitemap kullanıyorsanız kullanışlıdır.

- **Etiketleri Devre Dışı Bırak**
  - Devre Dışı: Etiket işlevselliği etkin kalır.
  - Etkin: Etiket işlevselliği devre dışı bırakılır. İçerik yönetimini basitleştirmek için kullanışlıdır.

- **Bileşenleri Devre Dışı Bırak**
  - Devre Dışı: Tüm bileşenler ve yan menüler etkin kalır.
  - Etkin: Tüm bileşenler ve yan menüler devre dışı bırakılır. Bu, performansı artırabilir ve gereksiz öğeleri kaldırabilir.

- **Yönetim Çubuğunu Devre Dışı Bırak**
  - Devre Dışı: Yönetim çubuğu etkin kalır.
  - Etkin: Tüm kullanıcılar için yönetim çubuğu devre dışı bırakılır. Kullanıcı deneyimini basitleştirmek için kullanışlıdır.

- **Otomatik Kaydetmeyi Devre Dışı Bırak**
  - Devre Dışı: Otomatik kaydetme özelliği etkin kalır.
  - Etkin: Otomatik kaydetme özelliği devre dışı bırakılır. Bu, veritabanı yükünü azaltabilir ve performansı artırabilir.

- **Gösterge Tablosunu Devre Dışı Bırak**
  - Devre Dışı: WordPress gösterge tablosu etkin kalır.
  - Etkin: WordPress gösterge tablosu devre dışı bırakılır. Gösterge tablosunu kullanmıyorsanız veya erişimi sınırlamak istiyorsanız kullanışlıdır.

- **Gösterge Tablosu Bileşenlerini Devre Dışı Bırak**
  - Devre Dışı: Gösterge tablosu bileşenleri etkin kalır.
  - Etkin: Gösterge tablosu bileşenleri devre dışı bırakılır. Bu, gösterge tablosunu basitleştirir ve performansı artırır.

- **Dosya Düzenleyicisini Devre Dışı Bırak**
  - Devre Dışı: Tema ve eklenti dosya düzenleyicisi etkin kalır.
  - Etkin: Tema ve eklenti dosya düzenleyicisi devre dışı bırakılır. Bu, güvenliği artırabilir.

- **Giriş Hatalarını Devre Dışı Bırak**
  - Devre Dışı: Giriş hata mesajları etkin kalır.
  - Etkin: Giriş hata mesajları gizlenir. Bu, güvenliği artırabilir.

- **Kullanıcı Kayıtlarını Devre Dışı Bırak**
  - Devre Dışı: Kullanıcı kayıt formu etkin kalır.
  - Etkin: Kullanıcı kayıt formu devre dışı bırakılır. Kullanıcı kayıtlarını sınırlamak istiyorsanız kullanışlıdır.

- **Sürüm Meta Verilerini Devre Dışı Bırak**
  - Devre Dışı: WordPress sürüm meta etiketi etkin kalır.
  - Etkin: WordPress sürüm meta etiketi kaldırılır. Bu, güvenliği artırabilir.

- **WP Üretici Etiketini Devre Dışı Bırak**
  - Devre Dışı: WordPress üretici etiketi etkin kalır.
  - Etkin: WordPress üretici etiketi kaldırılır. Bu, güvenliği artırabilir.

- **Yönetici Bildirimlerini Devre Dışı Bırak**
  - Devre Dışı: Yönetici bildirimleri etkin kalır.
  - Etkin: Yönetici bildirimleri devre dışı bırakılır. Bu, yönetim panelini basitleştirir.

- **Eklenti Güncellemelerini Devre Dışı Bırak**
  - Devre Dışı: Eklenti güncellemeleri etkin kalır.
  - Etkin: Eklenti güncellemeleri devre dışı bırakılır. Güncellemeleri manuel olarak kontrol etmeyi tercih ediyorsanız kullanışlıdır.

- **Tema Güncellemelerini Devre Dışı Bırak**
  - Devre Dışı: Tema güncellemeleri etkin kalır.
  - Etkin: Tema güncellemeleri devre dışı bırakılır. Güncellemeleri manuel olarak kontrol etmeyi tercih ediyorsanız kullanışlıdır.

- **Çekirdek Güncellemeleri Devre Dışı Bırak**
  - Devre Dışı: WordPress çekirdek güncellemeleri etkin kalır.
  - Etkin: WordPress çekirdek güncellemeleri devre dışı bırakılır. Güncellemeleri manuel olarak kontrol etmeyi tercih ediyorsanız kullanışlıdır.

- **Medya Boyutlarını Devre Dışı Bırak**
  - Devre Dışı: Ek medya boyutları etkin kalır.
  - Etkin: Ek medya boyutları devre dışı bırakılır. Bu, disk alanını optimize edebilir ve performansı artırabilir.

- **HTML Yorumlarını Devre Dışı Bırak**
  - Devre Dışı: HTML yorumları etkin kalır.
  - Etkin: HTML yorumları devre dışı bırakılır. Bu, HTML kaynak kodunu basitleştirebilir ve güvenliği artırabilir.

- **WooCommerce'i Devre Dışı Bırak**
  - Devre Dışı: WooCommerce işlevselliği etkin kalır.
  - Etkin: WooCommerce işlevselliği devre dışı bırakılır. WooCommerce'i geçici olarak devre dışı bırakmak istiyorsanız kullanışlıdır.

- **WP Bildirimlerini Devre Dışı Bırak**
  - Devre Dışı: WordPress bildirimleri etkin kalır.
  - Etkin: WordPress bildirimleri devre dışı bırakılır. Bu, yönetim panelini basitleştirir.

- **Heartbeat'i Devre Dışı Bırak**
  - Devre Dışı: WordPress heartbeat API'si etkin kalır.
  - Sınırlı: WordPress heartbeat API'si, sunucu yükünü azaltmak için 60 saniyelik bir aralıkla sınırlanır.
  - Etkin: WordPress heartbeat API'si devre dışı bırakılır. Bu, sunucu kaynaklarını koruyabilir ve performansı artırabilir.

- **Ön Uçta admin-ajax.php'yi Devre Dışı Bırak**
  - Devre Dışı: admin-ajax.php ön uçta etkin kalır.
  - Etkin: admin-ajax.php ön uçta devre dışı bırakılır. Bu, performansı artırabilir.

- **Statik Kaynaklardan Sorgu Dizelerini Kaldır**
  - Devre Dışı: Statik kaynaklarda sorgu dizeleri etkin kalır.
  - Etkin: Statik kaynaklardan sorgu dizeleri kaldırılır. Bu, önbelleğe alma ve performansı artırabilir.
  
- **API İstek Günlüğünü Devre Dışı Bırak**
  - Devre Dışı: API istek günlüğü etkin kalır.
  - Etkin: API istek günlüğü devre dışı bırakılır. Bu, sunucu yükünü azaltabilir.

- **WP-Cron'u Devre Dışı Bırak ve Gerçek Cron İşlerini Kullan**
  - Devre Dışı: WP-Cron etkin kalır.
  - Etkin: WP-Cron devre dışı bırakılır ve gerçek cron işleri kullanılır. Bu, zamanlanmış görevlerin daha verimli çalışmasını sağlar.

- **Post Kilitlemeyi Devre Dışı Bırak**
  - Devre Dışı: Post kilitleme etkin kalır.
  - Etkin: Post kilitleme devre dışı bırakılır. Tek yazarlı veya küçük ekiplerle çalışan siteler için faydalıdır.

- **Yüklemeleri Devre Dışı Bırak**
  - Devre Dışı: Yükleme işlevi etkin kalır.
  - Etkin: Medya, tema ve eklenti yükleme işlevlerini devre dışı bırakır. Yetkisiz yüklemeleri önlemek ve güvenliği artırmak için kullanışlıdır.

- **Site Sağlığı Kontrollerini Devre Dışı Bırak**
  - Devre Dışı: Site Sağlığı kontrolleri etkin kalır.
  - Etkin: Site Sağlığı kontrolleri devre dışı bırakılır. Bu, gereksiz yükü önlemek ve yönetim arayüzünü basitleştirmek için kullanışlı olabilir.

== Kurulum ==

1. `disable-master` klasörünü `/wp-content/plugins/` dizinine yükleyin.
2. WordPress'in 'Eklentiler' menüsünden eklentiyi etkinleştirin.
3. Ayarlar > Disable Master'a giderek eklentiyi yapılandırın.

== Sıkça Sorulan Sorular ==

= Bir işlevi nasıl devre dışı bırakabilirim? =

Ayarlar > Disable Master'a gidin ve devre dışı bırakmak istediğiniz işlevin yanındaki kutuyu işaretleyin. Ayarlarınızı uygulamak için 'Değişiklikleri Kaydet' butonuna tıklayın.

= Bir işlevi devre dışı bıraktıktan sonra yeniden etkinleştirebilir miyim? =

Evet, devre dışı bırakmak istediğiniz işlevin yanındaki kutunun işaretini kaldırın ve 'Değişiklikleri Kaydet' butonuna tıklayın.

= Bu eklenti diğer eklentilerle çakışır mı? =

Disable Master, diğer eklentilerle sorunsuz çalışacak şekilde tasarlanmıştır. Ancak, herhangi bir sorunla karşılaşırsanız, lütfen destek ekibimize bildirin.

== Ekran Görüntüleri ==

1. **Ayarlar Sayfası** - Disable Master ayarlar sayfasının genel görünümü.
2. **Özellik Seçimi** - Çeşitli WordPress işlevlerini kolayca etkinleştirin veya devre dışı bırakın.
3. **Değişiklikleri Kaydet** - Değişikliklerinizi kaydedin ve uygulayın.

== Değişiklikler ==

= 1.1.0 =
* Yeni özellik eklendi: Yüklemeleri Devre Dışı Bırak - Bu özellik, güvenliği artırmak için tüm dosya yüklemelerini (medya, eklentiler, temalar) engeller.
* Yeni özellik eklendi: Site Sağlığı Kontrollerini Devre Dışı Bırak - Bu özellik, yükü azaltmak ve yönetim arayüzünü basitleştirmek için Site Sağlığı kontrollerini devre dışı bırakır.
* Özellikleri sınıflar halinde düzenlemek ve daha iyi kod yönetimi için 'features' klasörünü yeniden yapılandırdık.
* Otomatik sınıf yükleme (autoloading) mekanizması eklendi.
* Yeni özellikler eklendi:
  - API İstek Kaydını Devre Dışı Bırakma
  - WP-Cron'u Devre Dışı Bırakma ve Gerçek Cron İşleri Kullanma
  - Gönderi Kilitlemeyi Devre Dışı Bırakma
* Admin panelinde 'System Check' sayfası eklendi. Bu sayfa, temalar ve diğer eklentilerle olası çakışmaları kontrol etmenize olanak tanır.
* Admin panelinde bilgi popup'ına 'Buy Me a Coffee' butonu eklendi.
* Çeşitli dil dosyası güncellemeleri ve hata düzeltmeleri.
* Ön uçta `admin-ajax.php`'yi devre dışı bırakma seçeneği eklendi.
* Statik kaynaklardan sorgu dizelerini kaldırma seçeneği eklendi.
* Heartbeat API kontrolü, devre dışı bırakma veya aralığı sınırlama seçenekleri ile geliştirildi.
* UI/UX tasarımı ve duyarlılık iyileştirildi.
* Türkçe dil desteği eklendi.
* Güvenlik ve performans iyileştirildi.

= 1.0.0 =
* İlk sürüm.

== Güncelleme Bildirimi ==

= 1.1.0 =
* Yeni özellik eklendi: Yüklemeleri Devre Dışı Bırak - Bu özellik, güvenliği artırmak için tüm dosya yüklemelerini (medya, eklentiler, temalar) engeller.
* Yeni özellik eklendi: Site Sağlığı Kontrollerini Devre Dışı Bırak - Bu özellik, yükü azaltmak ve yönetim arayüzünü basitleştirmek için Site Sağlığı kontrollerini devre dışı bırakır.
* Özellikleri sınıflar halinde düzenlemek ve daha iyi kod yönetimi için 'features' klasörünü yeniden yapılandırdık.
* Otomatik sınıf yükleme (autoloading) mekanizması eklendi.
* Yeni özellikler eklendi:
  - API İstek Kaydını Devre Dışı Bırakma
  - WP-Cron'u Devre Dışı Bırakma ve Gerçek Cron İşleri Kullanma
  - Gönderi Kilitlemeyi Devre Dışı Bırakma
* Admin panelinde 'System Check' sayfası eklendi. Bu sayfa, temalar ve diğer eklentilerle olası çakışmaları kontrol etmenize olanak tanır.
* Admin panelinde bilgi popup'ına 'Buy Me a Coffee' butonu eklendi.
* Çeşitli dil dosyası güncellemeleri ve hata düzeltmeleri.
* Ön uçta `admin-ajax.php`'yi devre dışı bırakma seçeneği eklendi.
* Statik kaynaklardan sorgu dizelerini kaldırma seçeneği eklendi.
* Heartbeat API kontrolü, devre dışı bırakma veya aralığı sınırlama seçenekleri ile geliştirildi.
* UI/UX tasarımı ve duyarlılık iyileştirildi.
* Türkçe dil desteği eklendi.
* Güvenlik ve performans iyileştirildi.

= 1.0.0 =
* İlk sürüm.

== Rastgele Bölüm ==

**Bilinen Sorunlar:**
- Şu anda bildirilen bilinen bir sorun yok. Eğer herhangi bir hata ile karşılaşırsanız veya geliştirme önerileriniz varsa, lütfen bizimle iletişime geçin.

**Gelecek Planlar:**
- Gelecek sürümlerde daha gelişmiş özelleştirme seçenekleri eklemeyi planlıyoruz.
- Performansı artırmak için popüler önbellekleme eklentileri ile entegrasyon.
- Devre dışı bırakılan işlevlerin etkisini izlemek için ayrıntılı günlükleme ve analiz özellikleri.
- Daha iyi özelleştirme sağlamak için bireysel WordPress özellikleri üzerinde daha ayrıntılı kontrol.

**Katkıda Bulunanlar:**
- Halil Kaya - Baş Geliştirici ve Sorumlu
- WordPress Türkiye Ekibi - Destek, Öneri ve Geliştirme

WordPress topluluğundan gelen geri bildirimleri ve katkıları çok takdir ediyoruz. Katkıda bulunmak isterseniz, lütfen halil@gencmedya.com adresinden bize ulaşın veya https://gencmedya.com adresindeki web sitemizi ziyaret edin. Disable Master'ı kullandığınız için teşekkür ederiz!
