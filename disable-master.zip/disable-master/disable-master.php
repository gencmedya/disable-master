<?php
/**
 * Plugin Name: Disable Master
 * Description: A comprehensive plugin to disable various WordPress functionalities.
 * Version: 1.1.0
 * Author: Gencmedya
 * Author URI: https://gencmedya.com
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Text Domain: disable-master
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load text domain for translations
function disable_master_load_textdomain() {
    load_plugin_textdomain('disable-master', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('init', 'disable_master_load_textdomain');

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'DisableMaster\\Features\\';
    $base_dir = __DIR__ . '/features/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

// Include admin page and control page
require_once plugin_dir_path(__FILE__) . 'includes/admin-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/control.php';

// Check which features are active
$options = get_option('disable_master_options');

// Use statements for features
use DisableMaster\Features\DisableAdminAjaxOnFrontend;
use DisableMaster\Features\DisableAdminBar;
use DisableMaster\Features\DisableAdminNotices;
use DisableMaster\Features\DisableAPIRequestLogging;
use DisableMaster\Features\DisableApplicationPasswords;
use DisableMaster\Features\DisableAuthorPages;
use DisableMaster\Features\DisableAutosave;
use DisableMaster\Features\DisableComments;
use DisableMaster\Features\DisableCoreUpdates;
use DisableMaster\Features\DisableDashboard;
use DisableMaster\Features\DisableDashboardWidgets;
use DisableMaster\Features\DisableEmbeds;
use DisableMaster\Features\DisableEmojis;
use DisableMaster\Features\DisableFeed;
use DisableMaster\Features\DisableFileEditor;
use DisableMaster\Features\DisableGutenberg;
use DisableMaster\Features\DisableHeartbeat;
use DisableMaster\Features\DisableHTMLComments;
use DisableMaster\Features\DisableLoginErrors;
use DisableMaster\Features\DisableMediaSizes;
use DisableMaster\Features\DisablePluginUpdates;
use DisableMaster\Features\DisablePostFormats;
use DisableMaster\Features\DisablePostLocking;
use DisableMaster\Features\DisableQueryStrings;
use DisableMaster\Features\DisableRestAPI;
use DisableMaster\Features\DisableRevisions;
use DisableMaster\Features\DisableRightClickAndSelection;
use DisableMaster\Features\DisableRSSFeeds;
use DisableMaster\Features\DisableSearch;
use DisableMaster\Features\DisableSelfPings;
use DisableMaster\Features\DisableSitemaps;
use DisableMaster\Features\DisableSource;
use DisableMaster\Features\DisableTags;
use DisableMaster\Features\DisableThemeUpdates;
use DisableMaster\Features\DisableTrackbacks;
use DisableMaster\Features\DisableUserRegistration;
use DisableMaster\Features\DisableVersionMeta;
use DisableMaster\Features\DisableWidgets;
use DisableMaster\Features\DisableWooCommerce;
use DisableMaster\Features\DisableWPCron;
use DisableMaster\Features\DisableWPGenerator;
use DisableMaster\Features\DisableWPNotification;
use DisableMaster\Features\DisableXMLRPCPingbacks;
use DisableMaster\Features\DisableUploads;
use DisableMaster\Features\DisableSiteHealth;

// Initialize feature classes
if (!empty($options['disable_admin_ajax_on_frontend'])) new DisableAdminAjaxOnFrontend(true);
if (!empty($options['disable_admin_bar'])) new DisableAdminBar(true);
if (!empty($options['disable_admin_notices'])) new DisableAdminNotices(true);
if (!empty($options['disable_api_request_logging'])) new DisableAPIRequestLogging(true);
if (!empty($options['disable_application_passwords'])) new DisableApplicationPasswords(true);
if (!empty($options['disable_author_pages'])) new DisableAuthorPages(true);
if (!empty($options['disable_autosave'])) new DisableAutosave(true);
if (!empty($options['disable_comments'])) new DisableComments(true);
if (!empty($options['disable_core_updates'])) new DisableCoreUpdates(true);
if (!empty($options['disable_dashboard'])) new DisableDashboard(true);
if (!empty($options['disable_dashboard_widgets'])) new DisableDashboardWidgets(true);
if (!empty($options['disable_embeds'])) new DisableEmbeds(true);
if (!empty($options['disable_emojis'])) new DisableEmojis(true);
if (!empty($options['disable_feed'])) new DisableFeed(true);
if (!empty($options['disable_file_editor'])) new DisableFileEditor(true);
if (!empty($options['disable_gutenberg'])) new DisableGutenberg(true);
if (!empty($options['disable_heartbeat'])) new DisableHeartbeat(true);
if (!empty($options['disable_html_comments'])) new DisableHTMLComments(true);
if (!empty($options['disable_login_errors'])) new DisableLoginErrors(true);
if (!empty($options['disable_media_sizes'])) new DisableMediaSizes(true);
if (!empty($options['disable_plugin_updates'])) new DisablePluginUpdates(true);
if (!empty($options['disable_post_formats'])) new DisablePostFormats(true);
if (!empty($options['disable_post_locking'])) new DisablePostLocking(true);
if (!empty($options['disable_query_strings'])) new DisableQueryStrings(true);
if (!empty($options['disable_rest_api'])) new DisableRestAPI(true);
if (!empty($options['disable_revisions'])) new DisableRevisions(true);
if (!empty($options['disable_right_click_and_selection'])) new DisableRightClickAndSelection(true);
if (!empty($options['disable_rss_feeds'])) new DisableRSSFeeds(true);
if (!empty($options['disable_search'])) new DisableSearch(true);
if (!empty($options['disable_self_pings'])) new DisableSelfPings(true);
if (!empty($options['disable_sitemaps'])) new DisableSitemaps(true);
if (!empty($options['disable_source'])) new DisableSource(true);
if (!empty($options['disable_tags'])) new DisableTags(true);
if (!empty($options['disable_theme_updates'])) new DisableThemeUpdates(true);
if (!empty($options['disable_trackbacks'])) new DisableTrackbacks(true);
if (!empty($options['disable_user_registration'])) new DisableUserRegistration(true);
if (!empty($options['disable_version_meta'])) new DisableVersionMeta(true);
if (!empty($options['disable_widgets'])) new DisableWidgets(true);
if (!empty($options['disable_woocommerce'])) new DisableWooCommerce(true);
if (!empty($options['disable_wp_cron'])) new DisableWPCron(true);
if (!empty($options['disable_wp_generator'])) new DisableWPGenerator(true);
if (!empty($options['disable_wp_notification'])) new DisableWPNotification(true);
if (!empty($options['disable_xmlrpc_pingbacks'])) new DisableXMLRPCPingbacks(true);
if (!empty($options['disable_uploads'])) new DisableUploads(true);
if (!empty($options['disable_site_health'])) new DisableSiteHealth(true);

// Activation hook
function disable_master_activate() {
    // Activation tasks
}
register_activation_hook(__FILE__, 'disable_master_activate');

// Deactivation hook
function disable_master_deactivate() {
    // Deactivation tasks
}
register_deactivation_hook(__FILE__, 'disable_master_deactivate');

// Enqueue admin styles
function disable_master_enqueue_admin_styles() {
    wp_enqueue_style('disable-master-custom-css', plugins_url('includes/admin-styles.css', __FILE__), array(), '1.0.0');
}
add_action('admin_enqueue_scripts', 'disable_master_enqueue_admin_styles');

// Add System Check submenu
function disable_master_add_control_menu() {
    add_submenu_page(
        'disable-master',
        __('System Check', 'disable-master'),
        __('System Check', 'disable-master'),
        'manage_options',
        'disable-master-control',
        'disable_master_control_page_html'
    );
}
add_action('admin_menu', 'disable_master_add_control_menu');
?>
